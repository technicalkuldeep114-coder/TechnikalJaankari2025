console.log("Welcome to TechnikalJaankari2025!");

function showWelcomeMessage() {
    alert("Welcome to TechnikalJaankari2025!");
}